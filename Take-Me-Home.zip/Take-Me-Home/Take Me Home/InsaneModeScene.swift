//
//  GameScene.swift
//  Take Me Home
//
//  Created by MakeSchool on 7/11/16.
//  Copyright (c) 2016 Jorge Avelar. All rights reserved.
//

import SpriteKit

//Tracking enum for game state
enum GameState2 {
    case ready, playing, gameOver
}

class InsaneModeScene: SKScene, SKPhysicsContactDelegate {
    //Game management
    
    
    var state: GameState2 = .ready
    
    //spriteNodes
    var asteroid = SKSpriteNode()
    var ufo = SKSpriteNode()
    var healthUp = SKSpriteNode()
    var healthUp2 = SKSpriteNode()
    var shootPowerUp = SKSpriteNode()
    var life = SKSpriteNode()
    var arrow = SKSpriteNode()
    var arrow2 = SKSpriteNode()
    var circle = SKSpriteNode(fileNamed: "circle")
    
    //emmiters
    var explosion = SKEmitterNode()
    var smoke = SKEmitterNode()
    var starsBackground = SKEmitterNode()
    
    //labels
    var scoreLabel = SKLabelNode(fontNamed: "Counter-Strike")
    var highScoreLabel = SKLabelNode(fontNamed: "Counter-Strike")
    var startLabel1 = SKLabelNode(fontNamed: "Counter-Strike")
    var startLabel2 = SKLabelNode(fontNamed: "Counter-Strike")
    var startLabel3 = SKLabelNode(fontNamed: "Counter-Strike")
    var startLabel4 = SKLabelNode(fontNamed: "Counter-Strike")
    var gameOverLabel = SKLabelNode(fontNamed: "Counter-Strike")
    
    var healthUpSound = SKAudioNode()
    var asteroidSound = SKAudioNode()
    var gameOverDeath = SKAudioNode()
    
    
    //MSButtonNode
    var restartButton = MSButtonNode(imageNamed: "restartButton")
    var controlButton = MSButtonNode(imageNamed: "controlButton")
    var homeButton = MSButtonNode(imageNamed: "homeButton")
    
    //nodes
    var nodeTouched = SKNode()
    var currentNodeTouched = SKNode()
    
    var isFingerOnUfo = false
    var isFingerOnButton = false
    
    var score: Int = 0 {
        didSet {
            scoreLabel.text = String(score)
        }
    }
    
    var lifeBar: CGFloat = 1.0 {
        didSet {
            //Cap Life
            if lifeBar > 1.0 { lifeBar = 1.0 }
            
            //Cap Life
            if lifeBar < 0 { lifeBar = 0 }
            
            //Life between 0.0 -> 1.0 aka 100%
            life.xScale = lifeBar
        }
    }
    
    // The Asteroid
    func createAsteroids() {
        
        //Calling the asteroid Sprite
        asteroid = SKSpriteNode(imageNamed: "asteroid")
        
        // asteroid scale
        asteroid.xScale = 0.1
        asteroid.yScale = 0.1
        asteroid.zPosition = 3
        
        // the positon where asteroids will spawn
        let randomPosition = CGFloat(arc4random() % 15 * 20 + 100)
        //print("Asteroid Position is " + String(randomPosition))
        asteroid.position.x = view!.frame.size.width/2
        asteroid.position.y = CGFloat(randomPosition) - 230
        
        
        
        // asteroid physics
        asteroid.physicsBody = SKPhysicsBody(circleOfRadius: asteroid.size.width/2)
        asteroid.physicsBody!.isDynamic = true
        asteroid.physicsBody!.affectedByGravity = false
        
        // the asteroids may only make contact with the player
        asteroid.physicsBody!.categoryBitMask    = PhysicsCategory.Asteroid
        asteroid.physicsBody!.contactTestBitMask = PhysicsCategory.Player
        asteroid.physicsBody!.collisionBitMask   = PhysicsCategory.None
        
        
        // asteroid color
        asteroid.colorBlendFactor = CGFloat(arc4random_uniform(60) + 20) / 100
        asteroid.color = UIColor(hue: 0.7, saturation: 0.5, brightness: 1, alpha: 1)
        
        
        // *** Random duration the asteroid will move across the screen
        let randomTime: UInt32 = 140
        let minTime = 311.0
        let randomDuration = (Double(arc4random_uniform(randomTime)) + minTime) / 100
        //print("Duration is " + String(randomDuration))
        let moveAction = SKAction.moveTo(x: -300, duration: randomDuration)
        let removeAction = SKAction.removeFromParent()
        let blockAction = SKAction.sequence([moveAction, removeAction])
        asteroid.run(blockAction)
        
        // *** Random rotation
        let randomRotation = (Double(arc4random_uniform(1256)) - 628) / 100
        //print("Rotation is " + String(randomRotation))
        let rotationRandomDuration = Double(arc4random_uniform(2) + 2)
        let action = SKAction.rotate(byAngle: CGFloat(randomRotation), duration: rotationRandomDuration)
        asteroid.run(SKAction.repeatForever(action))
        
        addChild(asteroid)
        //print("Asteroid")
    }
    
    //this will be the ufo the user will have to move up and down
    func setupPlayer() {
        ufo = SKSpriteNode(imageNamed: "ufoSprite")
        ufo.name = "ufoName"
        ufo.xScale = 0.13
        ufo.yScale = 0.13
        ufo.zPosition = 5
        ufo.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        ufo.position.x = view!.frame.size.width / 10 + -250
        ufo.position.y = 0 // view!.frame.size.height / 6
        
        ufo.physicsBody = SKPhysicsBody(circleOfRadius: 16)
        
        ufo.physicsBody!.affectedByGravity = false
        // The player will collide with the nothing, and make contact with asteroid and healthUP
        ufo.physicsBody!.categoryBitMask     = PhysicsCategory.Player
        ufo.physicsBody!.collisionBitMask    = PhysicsCategory.None
        ufo.physicsBody!.contactTestBitMask  = PhysicsCategory.Asteroid | PhysicsCategory.HealthUp | PhysicsCategory.ShootPowerUp
        addChild(ufo)
    }
    
    //this will setUP the healthUps for the game
    func makeHealthUps() {
        
        //calling the healthUp Sprite
        healthUp = SKSpriteNode(imageNamed: "lifeUp")
        healthUp.xScale = 0.025
        healthUp.yScale = 0.025
        healthUp.zPosition = 2
        healthUp.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        healthUp.alpha = 0.9
        
        // helathUps position
        healthUp.position.x = view!.frame.size.width/2
        let randomY = CGFloat(arc4random() % 15 * 20 + 100)
        healthUp.position.y = CGFloat(randomY) - 220
        
        healthUp2 = SKSpriteNode(imageNamed: "lifeUp2")
        healthUp2.xScale = 0.6
        healthUp2.yScale = 0.6
        healthUp2.zPosition = 3
        healthUp2.position.y = -20
        healthUp.addChild(healthUp2)
        
        
        // healthUps Physics
        healthUp.physicsBody = SKPhysicsBody(circleOfRadius:(healthUp.size.width/2))
        healthUp.physicsBody!.affectedByGravity = false
        healthUp.physicsBody!.isDynamic = false
        
        // healthUps will collide with nothing and contact only with player
        healthUp.physicsBody!.categoryBitMask   = PhysicsCategory.HealthUp
        healthUp.physicsBody!.collisionBitMask  = PhysicsCategory.None
        healthUp.physicsBody!.contactTestBitMask = PhysicsCategory.Player
        
        
        // duration the healthUps will move across the screen
        let moveAction = SKAction.moveTo(x: -300, duration: 3)
        let removeAction = SKAction.removeFromParent()
        let blockAction = SKAction.sequence([moveAction, removeAction])
        healthUp.run(blockAction)
        
        addChild(healthUp)
        //print("Health Up")
    }
    
    func makeShootPowerUps() {
        
        //calling the healthUp Sprite
        shootPowerUp = SKSpriteNode(imageNamed: "")
        shootPowerUp.xScale = 0.025
        shootPowerUp.yScale = 0.025
        shootPowerUp.zPosition = 2
        shootPowerUp.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        shootPowerUp.alpha = 0.9
        
        // helathUps position
        shootPowerUp.position.x = view!.frame.size.width/2
        let randomY = CGFloat(arc4random() % 15 * 20 + 100)
        shootPowerUp.position.y = CGFloat(randomY) - 220
        
        // healthUps Physics
        shootPowerUp.physicsBody = SKPhysicsBody(circleOfRadius:(shootPowerUp.size.width/2))
        shootPowerUp.physicsBody!.affectedByGravity = false
        shootPowerUp.physicsBody!.isDynamic = false
        
        // healthUps will collide with nothing and contact only with player
        shootPowerUp.physicsBody!.categoryBitMask   = PhysicsCategory.ShootPowerUp
        shootPowerUp.physicsBody!.collisionBitMask  = PhysicsCategory.None
        shootPowerUp.physicsBody!.contactTestBitMask = PhysicsCategory.Player
        
        
        // duration the healthUps will move across the screen
        let moveAction = SKAction.moveTo(x: -300, duration: 3)
        let removeAction = SKAction.removeFromParent()
        let blockAction = SKAction.sequence([moveAction, removeAction])
        shootPowerUp.run(blockAction)
        
        addChild(shootPowerUp)
    }
    
    // this is the lifeBar in the game
    func setUpLifeBar() {
        let lifeBar = SKSpriteNode(imageNamed: "life_bg")
        lifeBar.position = CGPoint(x: 0, y: 125)
        lifeBar.zPosition = 10
        lifeBar.yScale = 0.7
        addChild(lifeBar)
    }
    
    // this is the life inside the lifeBar
    func setUpLife(){
        life = SKSpriteNode(imageNamed: "life")
        life.position = CGPoint(x: -68.5, y: 116)
        life.anchorPoint = CGPoint(x: 0, y: 0)
        life.zPosition = 11
        life.yScale = 0.7
        life.xScale = 1.01
        addChild(life)
    }
    
    
    //this will create the asteroids action spawning from the right side of the screen
    func startMakingAsteroids() {
        
        // Make Asteroids
        let createAsteroids = SKAction.run {
            self.createAsteroids()
        }
        
        // delay between every asteroid
        let asteroidDelay = SKAction.wait(forDuration: 0.20)
        let asteroidSequence = SKAction.sequence([asteroidDelay, createAsteroids])
        let repeatAsteroids = SKAction.repeatForever(asteroidSequence)
        run(repeatAsteroids)
        //print("avoid me")
    }
    
    //this will create the powerUps action spawning from the right side of the screen
    func startMakingHealthUps() {
        
        // Make healthUps
        let createHealthUps = SKAction.run {
            self.makeHealthUps()
        }
        
        // delay between healthUps
        let healthUpsDelay = SKAction.wait(forDuration: 2)
        let healthUpsSequence = SKAction.sequence([healthUpsDelay, createHealthUps])
        let repeatHealthUps = SKAction.repeatForever(healthUpsSequence)
        // (runAction(repeatHealthUps), withKey: "actionA")
        
        self.run(repeatHealthUps, withKey: "actionA")
        //print("collect me")
    }
    
    func setUpControlButton() {
        controlButton.name = "buttonName"
        let position = ufo.position.y
        controlButton.position = CGPoint(x: 230, y: position)
        controlButton.zPosition = 5
        controlButton.xScale = 0.5
        controlButton.yScale = 0.5
        addChild(controlButton)
    }
    
    // this will create the background to the game
    func starsBackgroundCreation() {
        starsBackground = SKEmitterNode(fileNamed: "Stars")!
        starsBackground.targetNode = self.scene
        starsBackground.position = CGPoint(x: frame.size.width/2, y: (frame.size.height/2 - 150))
        starsBackground.advanceSimulationTime(30)
        starsBackground.zPosition = -1
        addChild(starsBackground)
    }
    
    func setUpStartLabel1() {
        startLabel1.fontSize = 32
        startLabel1.text = ("Drag the UFO")
        startLabel1.position = CGPoint(x: 0, y: 40)
        startLabel1.zPosition = 10
        addChild(startLabel1)
    }
    
    func setUpStartLablePart2() {
        startLabel2.fontSize = 40
        startLabel2.text  = ("OR")
        startLabel2.position = CGPoint(x: 0, y: 0)
        startLabel2.zPosition = 10
        addChild(startLabel2)
    }
    
    func setUpStartLabelPart3() {
        startLabel3.fontSize = 32
        startLabel3.text = ("Analog Stick")
        startLabel3.position = CGPoint(x: 0, y: -35)
        startLabel3.zPosition = 10
        addChild(startLabel3)
    }
    
    func setUpLabelPart4() {
        startLabel4.fontSize = 32
        startLabel4.text = ("To Begin")
        startLabel4.position = CGPoint(x: 0, y: -75)
        startLabel4.zPosition = 10
        addChild(startLabel4)
    }
    
    func instructionsCircle() {
        circle = SKSpriteNode(imageNamed: "circle")
        circle!.position = ufo.position
        circle!.xScale = 0.15
        circle!.yScale = 0.15
        circle!.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        circle!.zPosition = 4
        
        let action = SKAction.rotate(byAngle: CGFloat(-6.28), duration: 7)
        circle!.run(SKAction.repeatForever(action))
        
        addChild(circle!)
    }
    
    func setUpArrows() {
        arrow = SKSpriteNode(imageNamed: "arrow")
        arrow.position = CGPoint(x: 230, y: 90)
        arrow.xScale = 0.15
        arrow.yScale = 0.15
        arrow.zPosition = 10
        addChild(arrow)
        
        arrow2 = SKSpriteNode(imageNamed: "arrow2")
        arrow2.position = CGPoint(x: 230, y: -90)
        arrow2.xScale = 0.15
        arrow2.yScale = 0.15
        arrow2.zPosition = 10
        addChild(arrow2)
        
        let fade = SKAction.fadeOut(withDuration: 0.5)
        let wait = SKAction.wait(forDuration: 0.2)
        let fadeIn = SKAction.fadeIn(withDuration: 0.5)
        let seq = SKAction.sequence([fade, wait, fadeIn, wait])
        let forever = SKAction.repeatForever(seq)
        arrow.run(forever)
        arrow2.run(forever)
    }
    
    func fadeAwayInstructions() {
        let fadeAway = SKAction.fadeOut(withDuration: 0.5)
        let removeNode = SKAction.removeFromParent()
        let sequence = SKAction.sequence([fadeAway, removeNode])
        startLabel1.run(sequence)
        startLabel2.run(sequence)
        startLabel3.run(sequence)
        startLabel4.run(sequence)
        arrow.run(sequence)
        arrow2.run(sequence)
        circle!.run(sequence)
    }
    
    func setUpGameOverLabel() {
        gameOverLabel.fontSize = 32
        gameOverLabel.text  = ("GAME OVER")
        gameOverLabel.position = CGPoint(x: 0, y: 20)
        gameOverLabel.zPosition = 10
        gameOverLabel.alpha = 0
        let fadeIn = SKAction.fadeIn(withDuration: 1.5)
        let sequence = SKAction.sequence([fadeIn])
        gameOverLabel.run(sequence)
        addChild(gameOverLabel)
    }
    
    func setUpRestartButton() {
        restartButton.name = "restartButton"
        restartButton.position = CGPoint(x: 0, y: -60)
        restartButton.xScale = 0.8
        restartButton.yScale = 0.8
        restartButton.zPosition = 10
        addChild(restartButton)
        restartButton.state = .active
        restartButton.selectedHandler = {
            print(">>>> restart button handled! <<<<<")
            
            /* Grab reference to our SpriteKit view */
            let skView = self.view as SKView!
            
            /* Load Game scene */
            let scene = InsaneModeScene (fileNamed:"InsaneModeScene") as InsaneModeScene!
            
            /* Ensure correct aspect mode */
            scene?.scaleMode = .aspectFit
            
            /* Restart game scene */
            let reveal: SKTransition = SKTransition.fade(withDuration: 1)
            skView?.presentScene(scene!, transition: reveal)
            
            
            self.state = .ready
        }
    }
    
    func setUpHomeButton(){
        homeButton.name = "restartButton"
        homeButton.position = CGPoint(x: 0, y: -100)
        homeButton.xScale = 0.8
        homeButton.yScale = 0.8
        homeButton.zPosition = 10
        addChild(homeButton)
        homeButton.state = .active
        homeButton.selectedHandler = {
            print(">>>> restart button handled! <<<<<")
            
            /* Grab reference to our SpriteKit view */
            let skView = self.view as SKView!
            
            /* Load Game scene */
            let scene = MainScene (fileNamed:"MainScene") as MainScene!
            
            /* Ensure correct aspect mode */
            scene?.scaleMode = .aspectFit
            
            /* Restart game scene */
            let reveal: SKTransition = SKTransition.fade(withDuration: 1)
            skView?.presentScene(scene!, transition: reveal)
        }
    }
    
    func setUpScoreLabel() {
        scoreLabel.position = CGPoint(x: 130, y: 110)
        scoreLabel.fontSize = 48
        scoreLabel.text  = ("0")
        scoreLabel.zPosition = 5
        self.addChild(scoreLabel)
    }
    
    func scoreLabelCount() {
        let delay = SKAction.wait(forDuration: 1)
        let incrementScore = SKAction.run ({
            self.score = self.score + 1
            self.scoreLabel.text = "\(self.score)"
        })
        self.run(SKAction.repeatForever(SKAction.sequence([delay,incrementScore])), withKey: "scoreCount2")
    }
    
    func setUpHighScoreLabel() {
        highScoreLabel.position = CGPoint(x: 0, y: -15)
        highScoreLabel.fontSize = 24
        highScoreLabel.zPosition = 5
        highScoreLabel.alpha = 0
        let fadeIn = SKAction.fadeIn(withDuration: 1.5)
        let sequence = SKAction.sequence([fadeIn])
        highScoreLabel.run(sequence)
        addChild(highScoreLabel)
    }
    
    func playerScoreUpdate() {
        let highScore2 = UserDefaults().integer(forKey: "highscore2")
        if score > highScore2 {
            UserDefaults().set(score, forKey: "highscore2")
        }
        
        highScoreLabel.text = "High Score: " + UserDefaults().integer(forKey: "highscore2").description
    }
    
    func setUpLifeAlert() {
        if lifeBar <= 0.4 {
            let fade = SKAction.fadeOut(withDuration: 0.5)
            let wait = SKAction.wait(forDuration: 0.2)
            let fadeIn = SKAction.fadeIn(withDuration: 0.5)
            let seq = SKAction.sequence([fade, wait, fadeIn, wait])
            let forever = SKAction.repeatForever(seq)
            life.run(forever)
        }
    }
    override func didMove(to view: SKView) {
        /* Setup your scene here */
        
        
        self.physicsWorld.contactDelegate = self
        
        // Start making asteroids
        startMakingAsteroids()
        
        // Setup the ufo object
        setupPlayer()
        
        setUpControlButton()
        
        //Set the healthUps
        startMakingHealthUps()
        
        //Setup emitter background
        starsBackgroundCreation()
        
        //Setup Life Bar
        setUpLifeBar()
        
        //setUp the life
        setUpLife()
        
        //game directions pt.1
        setUpStartLabel1()
        
        //game directions pt. 2
        setUpStartLablePart2()
        setUpStartLabelPart3()
        setUpLabelPart4()
        setUpArrows()
        instructionsCircle()
        setUpScoreLabel()
    }
    
    
    // this will call and make the SKEmitter for the healthUp poof
    func makeHealthUpPoofAtPoint(_ point: CGPoint) {
        if let poof = SKEmitterNode(fileNamed: "healthUpPoof") {
            poof.xScale = 0.2
            poof.yScale = 0.2
            addChild(poof)
            poof.position = point
            let wait = SKAction.wait(forDuration: 2)
            let remove = SKAction.removeFromParent()
            let seq = SKAction.sequence([wait, remove])
            poof.run(seq)
        }
    }
    
    //this will call and make the SKEmitter for the asteroid poof
    func makeAsteroidPoofAtPoint(_ point: CGPoint) {
        if let asteroidPoof = SKEmitterNode(fileNamed: "asteroidPoof") {
            addChild(asteroidPoof)
            asteroidPoof.position = point
            let wait = SKAction.wait(forDuration: 0.8)
            let remove = SKAction.removeFromParent()
            let seq = SKAction.sequence([wait, remove])
            asteroidPoof.run(seq)
        }
    }
    
    func setUpExplosion(_ point: CGPoint) {
        if let explosion = SKEmitterNode(fileNamed: "explosion") {
            explosion.position = point
            addChild(explosion)
            let fadeAway = SKAction.fadeOut(withDuration: 0.5)
            let wait = SKAction.wait(forDuration: 0.8)
            let remove = SKAction.removeFromParent()
            let seq = SKAction.sequence([wait, fadeAway, wait, remove])
            explosion.run(seq)
            
        }
    }
    
    func setUpSmoke(_ point: CGPoint) {
        if let smoke = SKEmitterNode(fileNamed: "smoke") {
            smoke.position = ufo.position
            addChild(smoke)
            
        }
    }
    
    func hiddenControlButton() {
        isFingerOnButton = true
        isFingerOnUfo = false
        if isFingerOnUfo && isFingerOnButton {
            controlButton.alpha = 0.2
        }
    }
    
    func healthUpSoundEffect() {
        let sound = SKAction.playSoundFileNamed("healthUpSound", waitForCompletion: true)
        let remove = SKAction.removeFromParent()
        let sequence  = SKAction.sequence([sound, remove])
        healthUpSound.run(sequence)
        addChild(healthUpSound)
    }
    
    func aststeroidSoundEffect() {
        let sound = SKAction.playSoundFileNamed("asteroidExplosion", waitForCompletion: false)
        let remove = SKAction.removeFromParent()
        let sequence  = SKAction.sequence([sound, remove])
        asteroidSound.run(sequence)
        addChild(asteroidSound)
    }
    
    func gameOverDeathSoundEffect() {
        let sound = SKAction.playSoundFileNamed("explosion", waitForCompletion: false)
        let remove = SKAction.removeFromParent()
        let sequence  = SKAction.sequence([sound, remove])
        gameOverDeath.run(sequence)
        addChild(gameOverDeath)
    }
    
    // willremove node if the var is called
    
    var physicsObjectsToRemove = [SKNode]()
    
    func didBegin(_ contact: SKPhysicsContact) {
        
        if state == .ready {return}
        
        if state == .gameOver {return}
        
        let collision = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask
        
        // contact between asteroid and player
        if collision == PhysicsCategory.Asteroid | PhysicsCategory.Player {
            //print("Player Hit Asteroid")
            
            if contact.bodyA.node!.name == "asteroid" {
                // decrease health
                lifeBar -= 0.3
                aststeroidSoundEffect()
                makeAsteroidPoofAtPoint(contact.bodyA.node!.position)
                physicsObjectsToRemove.append(contact.bodyA.node!)
            } else {
                // decrease health
                lifeBar -= 0.3
                aststeroidSoundEffect()
                makeAsteroidPoofAtPoint(contact.bodyB.node!.position)
                physicsObjectsToRemove.append(contact.bodyB.node!)
            }
            
            
            // contact between player and healthUp
        } else if collision == PhysicsCategory.HealthUp | PhysicsCategory.Player {
            //print("Player Hit HealthUp")
            
            
            if contact.bodyA.node!.name == "healthUp" {
                /* Increment Health */
                lifeBar += 0.1
                healthUpSoundEffect()
                makeHealthUpPoofAtPoint(contact.bodyA.node!.position)
                physicsObjectsToRemove.append(contact.bodyA.node!)
            } else {
                /* Increment Health */
                lifeBar += 0.1
                healthUpSoundEffect()
                makeHealthUpPoofAtPoint(contact.bodyB.node!.position)
                physicsObjectsToRemove.append(contact.bodyB.node!)
            }
            
            // no contact
        } else if collision == PhysicsCategory.Player | PhysicsCategory.None {
            //print("*Player hit nothing*")
            
        }
    }
    
    //remove node after making contact
    override func didSimulatePhysics() {
        for node in physicsObjectsToRemove {
            node.removeFromParent()
        }
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        /* Called when a touch begins */
        
        
        //when touching the ufo
        let touch = touches.first
        let location = touch!.location(in: self)
        
        let node = atPoint(location)
        
        // Game not ready to play
        
        if state == .gameOver {
            return
        }
        
        // Game begins on first touch
        if state == .ready {
            state = .playing
            fadeAwayInstructions()
            scoreLabelCount()
            setUpLifeAlert()
        }
        
        if node.name == "ufoName" {
            print("Began touch on ufo")
            isFingerOnUfo = true
            let fadeAway = SKAction.fadeOut(withDuration: 0.5)
            let sequence = SKAction.sequence([fadeAway])
            controlButton.run(sequence)
            
        }
        
        if node.name == "buttonName" {
            print("touched control button")
            isFingerOnButton = true
            controlButton.alpha = 0.5
        }
        
        
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        if state == .gameOver {return}
        
        //if touching ufo, it will be able to move up and down
        if isFingerOnButton || isFingerOnUfo {
            
            //update the position of the paddle depending on how the player moves their finger.
            let touch = touches.first
            let location = touch!.location(in: self)
            let previousLocation = touch!.previousLocation(in: self)
            
            //Take the current position and add the difference between the new and the previous touch locations.
            var ufoY = ufo.position.y + (location.y - previousLocation.y)
            var buttonY = controlButton.position.y + (location.y - previousLocation.y)
            //Before repositioning the paddle, limit the position so that the paddle will not go off the screen to the left or right
            ufoY = max(ufoY, ufo.size.height/2)
            ufoY = min(ufoY, size.width - ufo.size.height/2)
            
            buttonY = max(buttonY, controlButton.size.height/2)
            buttonY = min(buttonY, size.width - controlButton.size.height/2)
            
            //move ufo based on touch location
            ufoY = location.y
            ufo.position.y = location.y
            
            buttonY = location.y
            controlButton.position.y = location.y
            
            
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        // when no longer touching ufo
        isFingerOnUfo = false
        print("No longer touching UFO")
        controlButton.alpha = 0
        let fadeIn = SKAction.fadeIn(withDuration: 0.3)
        let sequence = SKAction.sequence([fadeIn])
        controlButton.run(sequence)
        isFingerOnButton = false
        print("No longer touching button")
        controlButton.alpha = 1
    }
    
    
    
    func updateLife () {
        
        //Decrease Health
        lifeBar -= 0.0005
    }
    
    
    func gameOver() {
        /* Game over! */
        
        state = .gameOver
        
        ufo.run(SKAction.colorize(with: UIColor.red, colorBlendFactor: 1.0, duration: 0.50))
        
        setUpGameOverLabel()
        gameOverDeathSoundEffect()
        self.removeAction(forKey: "actionA")
        
        setUpExplosion(ufo.position)
        
        setUpSmoke(ufo.position)
        
        self.removeAction(forKey: "scoreCount2")
        
        setUpRestartButton()
        setUpHomeButton()
        
        playerScoreUpdate()
        
        setUpHighScoreLabel()
        
        let fadeAway = SKAction.fadeOut(withDuration: 1)
        let remove = SKAction.removeFromParent()
        let sequence = SKAction.sequence([fadeAway, remove])
        controlButton.run(sequence)
    }
    
    
    
    override func update(_ currentTime: TimeInterval) {
        /* Called before each frame is rendered */
        
        if state != .playing { return }
        
        // decreases life little by little
        updateLife()
        
        /* Has the player ran out of health? */
        if lifeBar == 0 {
            gameOver()
        }
        
    }
}
